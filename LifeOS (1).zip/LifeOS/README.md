# LifeOS — Full Stack Personal Operating System

A premium dark-UI productivity app with habit tracking, calorie logging, study planner, AI coach, goals, and calendar.

---

## Project Structure

```
LifeOS/
├── frontend/          ← React + Vite  (deploy to Vercel)
│   ├── src/
│   │   ├── app/           Pages (Dashboard, Habits, Study, Calories, Calendar, Goals, AI)
│   │   ├── components/    Reusable UI components
│   │   ├── context/       Toast notification context
│   │   ├── hooks/         usePomodoro, useHeatmap
│   │   ├── services/      api.js — axios client → backend
│   │   ├── styles/        globals.css — full design system
│   │   ├── utils/         constants.js — nav config, data, color maps
│   │   ├── App.jsx        Root component + page router
│   │   └── main.jsx       React entry point
│   ├── index.html
│   ├── vite.config.js     Dev proxy /api → localhost:5000
│   ├── vercel.json        SPA routing rewrite rule
│   ├── .env.local         Dev env (VITE_API_URL=empty → proxy)
│   ├── .env.production    Prod env (VITE_API_URL=Render URL)
│   └── package.json
│
└── backend/           ← Node.js + Express  (deploy to Render)
    ├── src/
    │   ├── config/
    │   │   └── db.js          MongoDB Atlas connection
    │   ├── models/
    │   │   ├── Meal.js
    │   │   ├── Habit.js
    │   │   └── Goal.js
    │   ├── routes/
    │   │   ├── meals.js       GET/POST/DELETE /api/meals
    │   │   ├── habits.js      GET/POST/PATCH/DELETE /api/habits
    │   │   ├── goals.js       GET/POST/PATCH/DELETE /api/goals
    │   │   └── ai.js          POST /api/ai/insight  /api/ai/chat
    │   └── server.js          Express app entry point
    ├── .env                   Secrets — NEVER commit
    ├── .gitignore
    └── package.json
```

---

## Quick Start (Local Development)

### 1. Backend

```bash
cd backend
npm install
# Edit .env — fill in MONGODB_URI and ANTHROPIC_API_KEY
npm run dev
# ✅ MongoDB Atlas connected
# 🚀 LifeOS backend running on port 5000
```

### 2. Frontend

```bash
cd frontend
npm install
npm run dev
# Open http://localhost:3000
```

Vite automatically proxies all `/api` calls to `http://localhost:5000` during dev.

---

## API Endpoints

| Method | Route                    | Description             |
|--------|--------------------------|-------------------------|
| GET    | /health                  | Health check            |
| GET    | /api/meals               | Get today's meals       |
| POST   | /api/meals               | Add a meal              |
| DELETE | /api/meals/:id           | Remove a meal           |
| GET    | /api/habits              | Get all habits          |
| POST   | /api/habits              | Create a habit          |
| PATCH  | /api/habits/:id/toggle   | Toggle today's check    |
| DELETE | /api/habits/:id          | Delete a habit          |
| GET    | /api/goals               | Get all goals           |
| POST   | /api/goals               | Create a goal           |
| PATCH  | /api/goals/:id           | Update goal progress    |
| DELETE | /api/goals/:id           | Delete a goal           |
| POST   | /api/ai/insight          | Get AI panel insight    |
| POST   | /api/ai/chat             | Send AI coach message   |

---

## Deployment

| Layer    | Platform      | Trigger            |
|----------|---------------|--------------------|
| Frontend | Vercel        | git push → auto    |
| Backend  | Render        | git push → auto    |
| Database | MongoDB Atlas | Always on (M0 free)|

### Environment Variables

**Backend (Render dashboard)**

| Key                | Value                         |
|--------------------|-------------------------------|
| NODE_ENV           | production                    |
| MONGODB_URI        | mongodb+srv://...             |
| ANTHROPIC_API_KEY  | sk-ant-...                    |
| CORS_ORIGINS       | https://yourapp.vercel.app    |

**Frontend (Vercel dashboard)**

| Key            | Value                                      |
|----------------|--------------------------------------------|
| VITE_API_URL   | https://lifeos-backend.onrender.com        |

---

## Tech Stack

- **Frontend** — React 18, Vite, Axios, custom CSS design system
- **Backend**  — Node.js 18+, Express 4, Mongoose, Helmet, Morgan
- **Database** — MongoDB Atlas (M0 free tier)
- **AI**       — Anthropic Claude (proxied through backend — API key never exposed to browser)
- **Deploy**   — Vercel (frontend) + Render (backend)
