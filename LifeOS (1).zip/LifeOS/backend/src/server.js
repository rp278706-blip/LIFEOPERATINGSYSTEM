import "dotenv/config";
import express from "express";
import cors    from "cors";
import helmet  from "helmet";
import morgan  from "morgan";

import { connectDB }    from "./config/db.js";
import mealsRouter      from "./routes/meals.js";
import habitsRouter     from "./routes/habits.js";
import goalsRouter      from "./routes/goals.js";
import aiRouter         from "./routes/ai.js";

const app  = express();
const PORT = process.env.PORT || 5000;

// ── Security & logging ───────────────────────────────────────
app.use(helmet());
app.use(morgan(process.env.NODE_ENV === "production" ? "combined" : "dev"));
app.use(express.json({ limit: "10kb" }));

// ── CORS ─────────────────────────────────────────────────────
const allowedOrigins = (process.env.CORS_ORIGINS ?? "http://localhost:3000").split(",").map(o => o.trim());

app.use(cors({
  origin(origin, callback) {
    // Allow requests with no origin (curl, Render health checks)
    if (!origin || allowedOrigins.includes(origin)) return callback(null, true);
    callback(new Error(`CORS: origin "${origin}" not allowed`));
  },
  credentials: true,
}));

// ── Routes ───────────────────────────────────────────────────
app.get("/health", (req, res) => res.json({ status: "ok", ts: Date.now() }));

app.use("/api/meals",  mealsRouter);
app.use("/api/habits", habitsRouter);
app.use("/api/goals",  goalsRouter);
app.use("/api/ai",     aiRouter);

// ── 404 ──────────────────────────────────────────────────────
app.use((req, res) => res.status(404).json({ error: `Route ${req.method} ${req.url} not found` }));

// ── Global error handler ──────────────────────────────────────
app.use((err, req, res, _next) => {
  console.error(err.stack);
  res.status(500).json({ error: err.message });
});

// ── Start ────────────────────────────────────────────────────
connectDB().then(() => {
  app.listen(PORT, () => console.log(`🚀  LifeOS backend running on port ${PORT}`));
});
