import mongoose from "mongoose";

const milestoneSchema = new mongoose.Schema({
  label: { type: String, required: true },
  done:  { type: Boolean, default: false },
});

const goalSchema = new mongoose.Schema(
  {
    title:      { type: String, required: true, trim: true },
    type:       { type: String, enum: ["short", "long"], default: "short" },
    deadline:   { type: String, default: "" },
    progress:   { type: Number, default: 0, min: 0, max: 100 },
    color:      { type: String, default: "violet" },
    icon:       { type: String, default: "🎯" },
    milestones: { type: [milestoneSchema], default: [] },
  },
  { timestamps: true }
);

export const Goal = mongoose.model("Goal", goalSchema);
