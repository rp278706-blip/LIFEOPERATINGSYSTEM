import mongoose from "mongoose";

const habitSchema = new mongoose.Schema(
  {
    name:    { type: String, required: true, trim: true },
    icon:    { type: String, default: "⭐" },
    streak:  { type: Number, default: 0 },
    history: { type: [Number], default: [0, 0, 0, 0, 0, 0, 0] },
    pct:     { type: Number, default: 0 },
  },
  { timestamps: true }
);

export const Habit = mongoose.model("Habit", habitSchema);
