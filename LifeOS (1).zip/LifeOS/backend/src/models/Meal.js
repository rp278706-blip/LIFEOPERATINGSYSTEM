import mongoose from "mongoose";

const mealSchema = new mongoose.Schema(
  {
    name:     { type: String, required: true, trim: true },
    type:     { type: String, enum: ["breakfast","lunch","dinner","snacks"], required: true },
    calories: { type: Number, required: true, min: 0 },
    protein:  { type: Number, default: 0, min: 0 },
    carbs:    { type: Number, default: 0, min: 0 },
    fat:      { type: Number, default: 0, min: 0 },
    icon:     { type: String, default: "🍽️" },
    date:     { type: String, default: () => new Date().toISOString().split("T")[0] },
  },
  { timestamps: true }
);

export const Meal = mongoose.model("Meal", mealSchema);
