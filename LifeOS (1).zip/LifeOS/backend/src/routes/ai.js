import { Router } from "express";
import axios       from "axios";

const router  = Router();
const CLAUDE  = "https://api.anthropic.com/v1/messages";
const MODEL   = "claude-sonnet-4-20250514";

const claudeHeaders = () => ({
  "Content-Type":      "application/json",
  "x-api-key":         process.env.ANTHROPIC_API_KEY,
  "anthropic-version": "2023-06-01",
});

// POST /api/ai/insight — short panel insight
router.post("/insight", async (req, res) => {
  const { prompt, context } = req.body;
  if (!prompt) return res.status(400).json({ error: "prompt is required" });

  try {
    const { data } = await axios.post(CLAUDE, {
      model:      MODEL,
      max_tokens: 180,
      messages: [{
        role:    "user",
        content: `${prompt}\n\nData: ${context}\n\nBe concise and actionable in 2 sentences max.`,
      }],
    }, { headers: claudeHeaders() });

    res.json({ text: data.content?.[0]?.text ?? "Keep pushing — consistency builds results!" });
  } catch (err) {
    console.error("AI insight error:", err.response?.data ?? err.message);
    res.status(500).json({ error: "AI request failed", text: "Keep up the momentum!" });
  }
});

// POST /api/ai/chat — coach chat message
router.post("/chat", async (req, res) => {
  const { userMsg, history = [], context = "" } = req.body;
  if (!userMsg) return res.status(400).json({ error: "userMsg is required" });

  const messages = [
    ...history
      .filter((m, i) => m.role !== "assistant" || i === 0)
      .map(m => ({ role: m.role, content: m.text ?? m.content ?? "" }))
      .filter(m => m.content),
    { role: "user", content: userMsg },
  ];

  try {
    const { data } = await axios.post(CLAUDE, {
      model:      MODEL,
      max_tokens: 350,
      system:     `You are LifeOS AI Coach — warm, direct, and data-aware. Context: ${context}. Keep replies under 80 words and be actionable.`,
      messages,
    }, { headers: claudeHeaders() });

    res.json({ text: data.content?.[0]?.text ?? "Keep pushing — consistency is the key!" });
  } catch (err) {
    console.error("AI chat error:", err.response?.data ?? err.message);
    res.status(500).json({ error: "AI request failed", text: "You're on track! Small consistent actions lead to massive results." });
  }
});

export default router;
