import { Router } from "express";
import { Habit }  from "../models/Habit.js";

const router = Router();

// GET /api/habits
router.get("/", async (req, res) => {
  try {
    const habits = await Habit.find().sort({ createdAt: 1 });
    res.json(habits);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/habits
router.post("/", async (req, res) => {
  try {
    const habit = await Habit.create(req.body);
    res.status(201).json(habit);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// PATCH /api/habits/:id/toggle — toggle today's habit completion
router.patch("/:id/toggle", async (req, res) => {
  try {
    const habit = await Habit.findById(req.params.id);
    if (!habit) return res.status(404).json({ error: "Habit not found" });

    const last    = habit.history[habit.history.length - 1];
    const checked = last === 1;

    habit.history = habit.history.map((v, i) =>
      i === habit.history.length - 1 ? (checked ? 0 : 1) : v
    );
    habit.streak = checked ? Math.max(0, habit.streak - 1) : habit.streak + 1;

    await habit.save();
    res.json(habit);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE /api/habits/:id
router.delete("/:id", async (req, res) => {
  try {
    await Habit.findByIdAndDelete(req.params.id);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
