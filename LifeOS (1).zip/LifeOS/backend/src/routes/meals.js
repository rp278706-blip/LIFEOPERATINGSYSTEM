import { Router } from "express";
import { Meal }   from "../models/Meal.js";

const router = Router();

// GET /api/meals — return today's meals
router.get("/", async (req, res) => {
  try {
    const today = new Date().toISOString().split("T")[0];
    const meals = await Meal.find({ date: today }).sort({ createdAt: 1 });
    res.json(meals);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/meals — add a meal
router.post("/", async (req, res) => {
  try {
    const meal = await Meal.create(req.body);
    res.status(201).json(meal);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// DELETE /api/meals/:id — remove a meal
router.delete("/:id", async (req, res) => {
  try {
    await Meal.findByIdAndDelete(req.params.id);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
