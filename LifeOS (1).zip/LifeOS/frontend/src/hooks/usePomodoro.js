import { useState, useEffect, useRef } from "react";
import { POMODORO_MODES } from "../utils/constants";

/**
 * usePomodoro — manages timer state, mode switching, and session counting.
 */
export function usePomodoro(onComplete) {
  const [mode,     setMode]     = useState("focus");
  const [timeLeft, setTimeLeft] = useState(POMODORO_MODES.focus.time);
  const [maxTime,  setMaxTime]  = useState(POMODORO_MODES.focus.time);
  const [active,   setActive]   = useState(false);
  const [sessions, setSessions] = useState(0);
  const tickRef = useRef(null);

  // Start / stop tick
  useEffect(() => {
    if (active) {
      tickRef.current = setInterval(() => {
        setTimeLeft(t => {
          if (t <= 1) {
            clearInterval(tickRef.current);
            setActive(false);
            setSessions(s => s + 1);
            onComplete?.();
            return maxTime;
          }
          return t - 1;
        });
      }, 1000);
    } else {
      clearInterval(tickRef.current);
    }
    return () => clearInterval(tickRef.current);
  }, [active, maxTime]);

  const switchMode = (m) => {
    setMode(m);
    setActive(false);
    const t = POMODORO_MODES[m].time;
    setTimeLeft(t);
    setMaxTime(t);
  };

  const toggle = () => setActive(a => !a);

  const reset = () => {
    setActive(false);
    setTimeLeft(maxTime);
  };

  const progress = ((maxTime - timeLeft) / maxTime) * 100;
  const formatted = `${String(Math.floor(timeLeft / 60)).padStart(2, "0")}:${String(timeLeft % 60).padStart(2, "0")}`;

  return { mode, active, timeLeft, maxTime, sessions, progress, formatted, switchMode, toggle, reset };
}
