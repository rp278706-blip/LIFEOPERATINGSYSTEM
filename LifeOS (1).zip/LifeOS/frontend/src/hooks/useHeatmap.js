import { useRef } from "react";

/**
 * useHeatmap — returns a stable array of 52×7 heat values (0-4).
 * Memoised via useRef so values don't regenerate on re-render.
 */
export function useHeatmap() {
  const data = useRef(
    Array.from({ length: 52 * 7 }, () => {
      const r = Math.random();
      if (r < 0.10) return 0;
      if (r < 0.35) return 1;
      if (r < 0.60) return 2;
      if (r < 0.80) return 3;
      return 4;
    })
  );
  return data.current;
}
