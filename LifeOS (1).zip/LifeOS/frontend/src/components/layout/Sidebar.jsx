import { NAV } from "../../utils/constants";

/**
 * Sidebar — collapsible navigation rail with logo, nav items, and user pill.
 *
 * Props:
 *   page        {string}    active page id
 *   setPage     {function}  navigate to page
 *   collapsed   {boolean}
 *   setCollapsed {function}
 */
export function Sidebar({ page, setPage, collapsed, setCollapsed }) {
  return (
    <aside className={`sidebar ${collapsed ? "collapsed" : ""}`}>
      <div className="sidebar-edge" />

      {/* Logo */}
      <div className="sidebar-logo">
        <div className="logo-icon">⚡</div>
        <div className="logo-wordmark">
          <div className="logo-name">LifeOS</div>
          <div className="logo-tagline">Personal Operating System</div>
        </div>
        <button className="sidebar-toggle" onClick={() => setCollapsed(c => !c)}>
          {collapsed ? "›" : "‹"}
        </button>
      </div>

      {/* Nav items */}
      <nav className="nav-body">
        <div className="nav-group-label">Navigation</div>
        {NAV.map(n => (
          <div
            key={n.id}
            className={`nav-item ${page === n.id ? "active" : ""}`}
            onClick={() => setPage(n.id)}
            title={collapsed ? n.label : ""}
          >
            <span className="nav-item-icon">{n.icon}</span>
            <span className="nav-item-label">{n.label}</span>
            {n.badge && <span className="nav-badge">{n.badge}</span>}
          </div>
        ))}
      </nav>

      {/* User pill */}
      <div className="sidebar-footer">
        <div className="user-pill">
          <div className="avatar">A</div>
          <div className="user-info">
            <div className="user-name">Arjun Singh</div>
            <div className="user-plan">✦ Pro Plan</div>
          </div>
        </div>
      </div>
    </aside>
  );
}
