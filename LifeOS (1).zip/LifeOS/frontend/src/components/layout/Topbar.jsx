import { NAV } from "../../utils/constants";

/**
 * Topbar — sticky glass header with breadcrumb, search, and actions.
 *
 * Props:
 *   page  {string}  current page id (used for breadcrumb label)
 */
export function Topbar({ page }) {
  const label = NAV.find(n => n.id === page)?.label ?? "Dashboard";

  return (
    <div className="topbar">
      {/* Breadcrumb */}
      <div className="topbar-breadcrumb">
        <span>LifeOS</span>
        <span className="breadcrumb-sep">›</span>
        <span className="breadcrumb-current">{label}</span>
      </div>

      {/* Search */}
      <div className="topbar-search">
        <span style={{ fontSize: 13, opacity: 0.4 }}>⌕</span>
        <input placeholder="Search anything..." />
        <span style={{ fontSize: 10, color: "var(--text4)", fontFamily: "var(--font-mono)" }}>⌘K</span>
      </div>

      {/* Actions */}
      <div className="topbar-actions">
        <div className="icon-btn notif-dot" title="Notifications">🔔</div>
        <div className="icon-btn" title="Settings">⚙</div>
      </div>
    </div>
  );
}
