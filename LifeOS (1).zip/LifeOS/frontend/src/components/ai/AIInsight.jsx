import { useState, useEffect, useCallback } from "react";
import { fetchInsight } from "../../utils/api";

/**
 * AIInsight — panel that auto-fetches a short AI analysis on mount.
 *
 * Props:
 *   prompt   {string}  what to analyse
 *   context  {string}  live user data string
 */
export function AIInsight({ prompt, context }) {
  const [text,    setText]    = useState("");
  const [loading, setLoading] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    setText("");
    const result = await fetchInsight(prompt, context);
    setText(result);
    setLoading(false);
  }, [prompt, context]);

  useEffect(() => { load(); }, []);

  return (
    <div className="ai-panel">
      <div className="ai-header">
        <span className="ai-badge">✦ AI INSIGHT</span>
        <span className="ai-title">Smart Analysis</span>
        {!loading && (
          <button
            className="btn btn-ghost btn-sm"
            style={{ marginLeft: "auto", padding: "3px 8px", fontSize: 11 }}
            onClick={load}
          >
            ↻ Refresh
          </button>
        )}
      </div>

      {loading ? (
        <div className="ai-dots">
          <div className="ai-dot" />
          <div className="ai-dot" />
          <div className="ai-dot" />
          <span style={{ fontSize: 12, color: "var(--text3)", marginLeft: 6 }}>Analyzing...</span>
        </div>
      ) : (
        <p className="ai-body">{text}</p>
      )}
    </div>
  );
}
