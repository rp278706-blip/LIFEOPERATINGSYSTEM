/**
 * BarChart — minimal animated bar chart.
 *
 * Props:
 *   data   {Array<{label: string, value: number}>}
 *   color  {string}  CSS color / var  (default var(--violet))
 */
export function BarChart({ data, color = "var(--violet)" }) {
  const max = Math.max(...data.map(d => d.value), 1);

  return (
    <div className="bars">
      {data.map((d, i) => (
        <div key={i} className="bar-col">
          <div
            className="bar-fill"
            style={{
              height:  `${(d.value / max) * 78}px`,
              background: color,
              opacity: i === data.length - 1 ? 1 : 0.45,
            }}
          />
          <span className="bar-lbl">{d.label}</span>
        </div>
      ))}
    </div>
  );
}
