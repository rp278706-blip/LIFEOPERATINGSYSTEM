/**
 * Modal — glassmorphic modal overlay with spring animation.
 *
 * Props:
 *   open      {boolean}   controls visibility
 *   onClose   {function}  called when overlay is clicked
 *   title     {string}    modal heading
 *   children  {ReactNode} form content
 *   footer    {ReactNode} action buttons (goes inside .modal-footer)
 */
export function Modal({ open, onClose, title, children, footer }) {
  if (!open) return null;

  return (
    <div
      className="modal-bg"
      onClick={e => e.target.classList.contains("modal-bg") && onClose?.()}
    >
      <div className="modal">
        <div className="modal-title">{title}</div>
        {children}
        {footer && <div className="modal-footer">{footer}</div>}
      </div>
    </div>
  );
}
