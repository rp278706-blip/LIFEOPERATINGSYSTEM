/**
 * ProgressRing — SVG circular progress indicator.
 *
 * Props:
 *   value      {number}  current value
 *   max        {number}  maximum value  (default 100)
 *   color      {string}  stroke color   (default var(--violet))
 *   size       {number}  diameter px    (default 100)
 *   sw         {number}  stroke width   (default 8)
 *   label      {string?} small label below percentage
 */
export function ProgressRing({ value, max = 100, color = "var(--violet)", size = 100, sw = 8, label }) {
  const r    = (size - sw) / 2;
  const circ = 2 * Math.PI * r;
  const pct  = Math.min(value / max, 1);

  return (
    <div className="pring" style={{ width: size, height: size }}>
      <svg
        width={size} height={size}
        style={{ position: "absolute", inset: 0, transform: "rotate(-90deg)" }}
      >
        <circle
          cx={size / 2} cy={size / 2} r={r}
          fill="none" stroke="rgba(255,255,255,0.05)" strokeWidth={sw}
        />
        <circle
          cx={size / 2} cy={size / 2} r={r}
          fill="none" stroke={color}
          strokeWidth={sw}
          strokeDasharray={circ}
          strokeDashoffset={circ * (1 - pct)}
          strokeLinecap="round"
          style={{ transition: "stroke-dashoffset 1s var(--ease-smooth)" }}
        />
      </svg>

      <div className="pring-inner">
        <div
          className="pring-val"
          style={{ fontSize: size < 90 ? 15 : size < 120 ? 20 : 26, color }}
        >
          {Math.round(pct * 100)}%
        </div>
        {label && <div className="pring-lbl">{label}</div>}
      </div>
    </div>
  );
}
