/**
 * EmptyState — friendly placeholder shown when a list is empty.
 *
 * Props:
 *   icon    {string}   emoji
 *   title   {string}   bold heading
 *   sub     {string?}  helper text
 */
export function EmptyState({ icon, title, sub }) {
  return (
    <div className="empty">
      <div className="empty-icon">{icon}</div>
      <div className="empty-title">{title}</div>
      {sub && <div className="empty-sub">{sub}</div>}
    </div>
  );
}
