/**
 * StatCard — colored KPI tile with glow, top-edge gradient, and progress bar.
 *
 * Props:
 *   variant   {"sv"|"st"|"sa"|"sr"}  color variant
 *   emoji     {string}               icon emoji
 *   label     {string}               uppercase label
 *   value     {string|number}        large displayed number
 *   sub       {string}               subtitle below value
 *   progress  {number}               0–100 fill width for pbar
 *   barClass  {string}               pbar-fill color class (cv/ct/ca/cr/cs)
 */
export function StatCard({ variant, emoji, label, value, sub, progress, barClass }) {
  return (
    <div className={`stat-card ${variant} hoverable`}>
      <div className="stat-glow-bg" />
      <span className="stat-emoji">{emoji}</span>
      <div className="stat-label">{label}</div>
      <div className="stat-value">{value}</div>
      <div className="stat-sub">{sub}</div>
      {progress !== undefined && (
        <div className="pbar mt8">
          <div className={`pbar-fill ${barClass}`} style={{ width: `${Math.min(progress, 100)}%` }} />
        </div>
      )}
    </div>
  );
}
