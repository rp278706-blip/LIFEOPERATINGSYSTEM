import axios from "axios";

/**
 * Axios client — base URL switches automatically:
 *   Development : Vite proxy forwards /api → http://localhost:5000 (VITE_API_URL is empty)
 *   Production  : VITE_API_URL = https://lifeos-backend.onrender.com (set in Vercel dashboard)
 */
const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL ?? "",
  headers: { "Content-Type": "application/json" },
  timeout: 30_000,
});

// ── Meals ──────────────────────────────────────────────────
export const getMeals   = ()     => api.get("/api/meals");
export const addMeal    = (meal) => api.post("/api/meals", meal);
export const deleteMeal = (id)   => api.delete(`/api/meals/${id}`);

// ── Habits ─────────────────────────────────────────────────
export const getHabits   = ()    => api.get("/api/habits");
export const addHabit    = (h)   => api.post("/api/habits", h);
export const toggleHabit = (id)  => api.patch(`/api/habits/${id}/toggle`);
export const deleteHabit = (id)  => api.delete(`/api/habits/${id}`);

// ── Goals ──────────────────────────────────────────────────
export const getGoals   = ()    => api.get("/api/goals");
export const addGoal    = (g)   => api.post("/api/goals", g);
export const deleteGoal = (id)  => api.delete(`/api/goals/${id}`);

// ── AI ─────────────────────────────────────────────────────
export const getAIInsight  = (payload) => api.post("/api/ai/insight", payload);
export const sendAIMessage = (payload) => api.post("/api/ai/chat", payload);
