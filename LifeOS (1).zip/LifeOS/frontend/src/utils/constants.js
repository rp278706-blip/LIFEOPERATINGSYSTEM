// ============================================================
// NAVIGATION CONFIG
// ============================================================
export const NAV = [
  { id: "dashboard", label: "Dashboard",  icon: "⚡" },
  { id: "calories",  label: "Nutrition",  icon: "🍎" },
  { id: "study",     label: "Study",      icon: "📚" },
  { id: "habits",    label: "Habits",     icon: "✅" },
  { id: "calendar",  label: "Calendar",   icon: "📅" },
  { id: "goals",     label: "Goals",      icon: "🎯" },
  { id: "ai",        label: "AI Coach",   icon: "✨", badge: "AI" },
];

// ============================================================
// MOTIVATIONAL QUOTES
// ============================================================
export const QUOTES = [
  { text: "The secret of getting ahead is getting started.", author: "Mark Twain" },
  { text: "Small daily improvements over time lead to stunning results.", author: "Robin Sharma" },
  { text: "Discipline is choosing between what you want now and what you want most.", author: "Abraham Lincoln" },
  { text: "The body achieves what the mind believes.", author: "Napoleon Hill" },
  { text: "Do the hard jobs first. The easy jobs will take care of themselves.", author: "Dale Carnegie" },
];

// ============================================================
// INITIAL DATA
// ============================================================
export const INITIAL_MEALS = [
  { id: 1, name: "Oatmeal with Berries",    type: "breakfast", calories: 310, protein: 12, carbs: 54, fat: 6,  icon: "🥣" },
  { id: 2, name: "Grilled Chicken Salad",   type: "lunch",     calories: 480, protein: 42, carbs: 18, fat: 14, icon: "🥗" },
  { id: 3, name: "Banana",                  type: "snacks",    calories: 105, protein: 1,  carbs: 27, fat: 0,  icon: "🍌" },
  { id: 4, name: "Protein Shake",           type: "snacks",    calories: 150, protein: 25, carbs: 8,  fat: 3,  icon: "🥤" },
];

export const INITIAL_HABITS = [
  { id: 1, name: "Morning Workout",  icon: "💪", streak: 12, history: [1,1,1,0,1,1,1], pct: 85 },
  { id: 2, name: "Read 20 mins",     icon: "📖", streak: 7,  history: [1,1,0,1,1,1,1], pct: 78 },
  { id: 3, name: "DSA Practice",     icon: "💻", streak: 5,  history: [1,1,0,0,1,1,1], pct: 65 },
  { id: 4, name: "Meditate",         icon: "🧘", streak: 3,  history: [0,1,1,0,0,1,1], pct: 55 },
  { id: 5, name: "Drink 8 Glasses",  icon: "💧", streak: 15, history: [1,1,1,1,1,1,1], pct: 92 },
];

export const INITIAL_GOALS = [
  {
    id: 1, title: "Crack GATE 2026", type: "long",  deadline: "Feb 2026",
    progress: 38, color: "violet", icon: "🎯",
    milestones: [
      { id: 1, label: "Complete Engineering Maths", done: true  },
      { id: 2, label: "Finish Networks & OS",       done: true  },
      { id: 3, label: "Give 10 Mock Tests",         done: false },
      { id: 4, label: "Revise all subjects",        done: false },
    ],
  },
  {
    id: 2, title: "Lose 8 kg", type: "long", deadline: "Jun 2025",
    progress: 62, color: "teal", icon: "🏃",
    milestones: [
      { id: 1, label: "Lose first 2 kg",  done: true  },
      { id: 2, label: "Lose 5 kg",        done: true  },
      { id: 3, label: "Reach target weight", done: false },
    ],
  },
  {
    id: 3, title: "Build 3 Projects", type: "short", deadline: "Mar 2025",
    progress: 66, color: "amber", icon: "🛠️",
    milestones: [
      { id: 1, label: "Portfolio Website",   done: true  },
      { id: 2, label: "React CRUD App",      done: true  },
      { id: 3, label: "Full-stack Project",  done: false },
    ],
  },
];

export const STUDY_BLOCKS = [
  { time: "06:00", subject: "Data Structures",       duration: "1.5h", type: "v" },
  { time: "08:00", subject: "Gym / Physical Training", duration: "1h",   type: "t" },
  { time: "10:00", subject: "Operating Systems",     duration: "2h",   type: "v" },
  { time: "13:00", subject: "Lunch Break",           duration: "45m",  type: "a" },
  { time: "14:00", subject: "Computer Networks",     duration: "1.5h", type: "v" },
  { time: "16:00", subject: "Mock Test Practice",    duration: "2h",   type: "r" },
  { time: "19:00", subject: "Revision + Notes",      duration: "1h",   type: "v" },
];

export const CALENDAR_EVENTS = (today) => [
  { date: today.getDate(),   month: today.getMonth(), title: "GATE Mock Test",  color: "violet", icon: "📝", time: "2:00 PM" },
  { date: today.getDate()+2, month: today.getMonth(), title: "Gym Session",     color: "teal",   icon: "💪", time: "7:00 AM" },
  { date: today.getDate()-1, month: today.getMonth(), title: "Assignment Due",  color: "rose",   icon: "📋", time: "11:59 PM" },
  { date: today.getDate()+5, month: today.getMonth(), title: "Project Review",  color: "amber",  icon: "📊", time: "11:00 AM" },
];

// ============================================================
// CONSTANTS
// ============================================================
export const GOALS_CONFIG = {
  calories: 2200,
  protein:  150,
  carbs:    250,
  fat:      65,
  studyHrs: 8,
};

export const MEAL_ICONS = {
  breakfast: "☀️",
  lunch:     "🥗",
  dinner:    "🌙",
  snacks:    "🍎",
};

export const POMODORO_MODES = {
  focus: { label: "Focus",       time: 25 * 60, color: "var(--violet)" },
  short: { label: "Short Break", time: 5  * 60, color: "var(--teal)"   },
  long:  { label: "Long Break",  time: 15 * 60, color: "var(--sky)"    },
};

export const COLOR_MAP = {
  violet: "var(--violet)",
  teal:   "var(--teal)",
  amber:  "var(--amber)",
  rose:   "var(--rose)",
  sky:    "var(--sky)",
};

export const TAG_CLASS_MAP = {
  violet: "tag-v",
  teal:   "tag-t",
  amber:  "tag-a",
  rose:   "tag-r",
  sky:    "tag-s",
};
