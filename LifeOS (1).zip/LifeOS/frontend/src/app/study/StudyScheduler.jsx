import { STUDY_BLOCKS, POMODORO_MODES } from "../../utils/constants";
import { BarChart }  from "../../components/charts";
import { AIInsight } from "../../components/ai";
import { usePomodoro } from "../../hooks/usePomodoro";
import { useToast }    from "../../context/ToastContext";

const WEEK_STUDY = [
  { label: "M", value: 7 }, { label: "T", value: 8 }, { label: "W", value: 5 },
  { label: "T", value: 9 }, { label: "F", value: 6 }, { label: "S", value: 8 },
  { label: "S", value: 6.5 },
];

const STUDY_CTX = `Schedule: ${STUDY_BLOCKS.map(b => `${b.subject} ${b.duration}`).join(", ")}. Avg: 7.1h/day.`;

export function StudyScheduler() {
  const toast = useToast();

  const { mode, active, sessions, progress, formatted, switchMode, toggle, reset } =
    usePomodoro(() => toast("Pomodoro complete! 🍅", "success"));

  const modeColor = POMODORO_MODES[mode].color;
  const r    = 88;
  const circ = 2 * Math.PI * r;

  return (
    <div className="page">
      {/* Header */}
      <div className="ph">
        <div>
          <div className="ph-title">📚 Study Planner</div>
          <div className="ph-sub">Plan, focus, and track your learning</div>
        </div>
        <div className="ph-actions">
          <button className="btn btn-primary">+ Add Block</button>
        </div>
      </div>

      <div className="g2 mb20">
        {/* Today's Schedule */}
        <div className="card" style={{ gridRow: "span 2" }}>
          <div className="card-title"><span className="card-title-icon">🗓</span>Today's Schedule</div>
          {STUDY_BLOCKS.map((b, i) => (
            <div key={i} className="tblock">
              <div className="tblock-time">{b.time}</div>
              <div className={`tblock-pill tb-${b.type}`}>
                <div style={{ fontWeight: 600, fontSize: 13 }}>{b.subject}</div>
                <div style={{ fontSize: 11, opacity: 0.75, marginTop: 2 }}>{b.duration}</div>
              </div>
            </div>
          ))}
        </div>

        {/* Pomodoro Timer */}
        <div className="card" style={{ textAlign: "center" }}>
          <div className="card-title" style={{ justifyContent: "center" }}>
            <span className="card-title-icon">⏱</span>Pomodoro Timer
          </div>

          {/* Mode switcher */}
          <div className="row gap4 mb16" style={{ justifyContent: "center" }}>
            {Object.entries(POMODORO_MODES).map(([k, v]) => (
              <button
                key={k}
                className={`chip ${mode === k ? "active" : ""}`}
                style={{ fontSize: 11 }}
                onClick={() => switchMode(k)}
              >
                {v.label}
              </button>
            ))}
          </div>

          {/* Ring */}
          <div className="pomo-wrap">
            {active && <div className="pomo-pulse" style={{ borderColor: modeColor, opacity: 0.3 }} />}
            <svg
              className="pomo-svg"
              viewBox="0 0 200 200"
              style={{ position: "absolute", inset: 0, width: "100%", height: "100%", transform: "rotate(-90deg)" }}
            >
              <circle cx="100" cy="100" r={r} fill="none" stroke="rgba(255,255,255,0.04)" strokeWidth="9" />
              <circle
                cx="100" cy="100" r={r}
                fill="none" stroke={modeColor}
                strokeWidth="9"
                strokeDasharray={circ}
                strokeDashoffset={circ * (1 - progress / 100)}
                strokeLinecap="round"
                style={{
                  transition: active ? "stroke-dashoffset 1s linear" : "stroke-dashoffset 0.5s",
                  filter: `drop-shadow(0 0 8px ${modeColor})`,
                }}
              />
            </svg>
            <div className="pomo-inner">
              <div className="pomo-time" style={{ color: modeColor }}>{formatted}</div>
              <div className="pomo-lbl">{active ? POMODORO_MODES[mode].label : "Ready to focus"}</div>
            </div>
          </div>

          <div className="row gap8 mt16" style={{ justifyContent: "center" }}>
            <button className="btn btn-ghost btn-sm" onClick={reset}>↺ Reset</button>
            <button
              className="btn btn-primary"
              style={{ background: `linear-gradient(135deg, ${modeColor}, ${modeColor}bb)` }}
              onClick={toggle}
            >
              {active ? "⏸ Pause" : "▶ Start"}
            </button>
            <span className="tag tag-a">🍅 {sessions}</span>
          </div>
        </div>

        {/* Weekly stats */}
        <div className="card">
          <div className="card-title"><span className="card-title-icon">📈</span>This Week</div>
          <BarChart data={WEEK_STUDY} color="var(--violet)" />
          <div className="row gap8 mt12">
            <div className="tag tag-v">Avg: 7.1h/day</div>
            <div className="tag tag-t">🔥 14-day streak</div>
          </div>
        </div>
      </div>

      {/* AI Insight */}
      <AIInsight
        prompt="Analyze the student's study schedule and give recommendations to optimize learning."
        context={STUDY_CTX}
      />
    </div>
  );
}
