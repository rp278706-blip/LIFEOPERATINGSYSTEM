import { useState } from "react";
import { COLOR_MAP, TAG_CLASS_MAP } from "../../utils/constants";
import { ProgressRing } from "../../components/ui/ProgressRing";
import { Modal }        from "../../components/ui/Modal";
import { AIInsight }    from "../../components/ai";
import { useToast }     from "../../context/ToastContext";

const EMPTY_GOAL = { title: "", type: "short", deadline: "", icon: "🎯" };

export function Goals({ goals, setGoals }) {
  const [showModal, setShowModal] = useState(false);
  const [newGoal,   setNewGoal]   = useState(EMPTY_GOAL);
  const toast = useToast();

  const addGoal = () => {
    if (!newGoal.title) return;
    setGoals(prev => [...prev, {
      id:         Date.now(),
      ...newGoal,
      progress:   0,
      milestones: [],
      color:      "violet",
    }]);
    setNewGoal(EMPTY_GOAL);
    setShowModal(false);
    toast("Goal created!", "success");
  };

  const insightCtx = goals.map(g => `${g.title} ${g.progress}% due ${g.deadline}`).join(", ");

  return (
    <div className="page">
      {/* Header */}
      <div className="ph">
        <div>
          <div className="ph-title">🎯 Goals</div>
          <div className="ph-sub">Set targets, track milestones, achieve more</div>
        </div>
        <div className="ph-actions">
          <button className="btn btn-primary" onClick={() => setShowModal(true)}>+ New Goal</button>
        </div>
      </div>

      {/* AI Insight */}
      <div className="mb20">
        <AIInsight
          prompt="Analyze the user's goals and give actionable advice to achieve them faster."
          context={insightCtx}
        />
      </div>

      {/* Goal cards */}
      <div className="g2">
        {goals.map(g => {
          const col      = COLOR_MAP[g.color]     ?? "var(--violet)";
          const tagClass = TAG_CLASS_MAP[g.color]  ?? "tag-v";
          return (
            <div key={g.id} className="card goal-card hoverable">
              {/* Card header */}
              <div className="row-between mb16">
                <div className="row gap10">
                  <span style={{ fontSize: 22 }}>{g.icon}</span>
                  <div>
                    <div className="goal-title">{g.title}</div>
                    <div className="goal-meta">
                      Due: {g.deadline} · {g.type === "long" ? "Long-term" : "Short-term"}
                    </div>
                  </div>
                </div>
                <span className={`tag ${tagClass}`}>{g.type}</span>
              </div>

              {/* Progress ring + numbers */}
              <div className="row gap16 mb16">
                <ProgressRing value={g.progress} max={100} color={col} size={82} sw={7} />
                <div>
                  <div style={{ fontFamily: "var(--font-display)", fontSize: 28, fontWeight: 800, color: col, letterSpacing: "-1px" }}>
                    {g.progress}%
                  </div>
                  <div className="tsmall tmuted">Complete</div>
                  <div className="txs tdim mt8">{100 - g.progress}% remaining</div>
                </div>
              </div>

              {/* Progress bar */}
              <div className="pbar">
                <div
                  className="pbar-fill"
                  style={{ width: `${g.progress}%`, background: `linear-gradient(90deg, ${col}, ${col}bb)` }}
                />
              </div>

              {/* Milestones */}
              {g.milestones.length > 0 && (
                <>
                  <div className="divider" />
                  <div className="txs tdim" style={{ marginBottom: 6, fontWeight: 700, letterSpacing: "0.8px" }}>
                    MILESTONES
                  </div>
                  {g.milestones.map(m => (
                    <div key={m.id} className="milestone">
                      <div className={`ms-dot ${m.done ? "done" : ""}`}>{m.done ? "✓" : ""}</div>
                      <span style={{
                        color:          m.done ? "var(--text3)" : "var(--text)",
                        textDecoration: m.done ? "line-through" : "none",
                        fontSize: 13,
                      }}>
                        {m.label}
                      </span>
                    </div>
                  ))}
                </>
              )}
            </div>
          );
        })}
      </div>

      {/* Add Goal Modal */}
      <Modal
        open={showModal}
        onClose={() => setShowModal(false)}
        title="Create Goal"
        footer={
          <>
            <button className="btn btn-ghost" onClick={() => setShowModal(false)}>Cancel</button>
            <button className="btn btn-primary" onClick={addGoal}>Create Goal</button>
          </>
        }
      >
        <div className="form-group">
          <label>Goal Title</label>
          <input
            placeholder="e.g. Learn React in 30 days"
            value={newGoal.title}
            onChange={e => setNewGoal(p => ({ ...p, title: e.target.value }))}
          />
        </div>
        <div className="g2" style={{ gap: 10 }}>
          <div className="form-group">
            <label>Type</label>
            <select value={newGoal.type} onChange={e => setNewGoal(p => ({ ...p, type: e.target.value }))}>
              <option value="short">Short-term</option>
              <option value="long">Long-term</option>
            </select>
          </div>
          <div className="form-group">
            <label>Icon</label>
            <input
              placeholder="🎯"
              value={newGoal.icon}
              onChange={e => setNewGoal(p => ({ ...p, icon: e.target.value }))}
            />
          </div>
        </div>
        <div className="form-group">
          <label>Deadline</label>
          <input
            placeholder="e.g. Jun 2025"
            value={newGoal.deadline}
            onChange={e => setNewGoal(p => ({ ...p, deadline: e.target.value }))}
          />
        </div>
      </Modal>
    </div>
  );
}
