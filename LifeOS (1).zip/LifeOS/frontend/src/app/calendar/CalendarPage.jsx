import { useState } from "react";
import { CALENDAR_EVENTS, STUDY_BLOCKS } from "../../utils/constants";

const DAY_NAMES   = ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"];
const MONTH_NAMES = [
  "January","February","March","April","May","June",
  "July","August","September","October","November","December",
];

const COLOR_VAR = {
  violet: "var(--violet)",
  teal:   "var(--teal)",
  amber:  "var(--amber)",
  rose:   "var(--rose)",
};

export function CalendarPage() {
  const today = new Date();
  const [curr, setCurr] = useState({ m: today.getMonth(), y: today.getFullYear() });

  const events       = CALENDAR_EVENTS(today);
  const daysInMonth  = new Date(curr.y, curr.m + 1, 0).getDate();
  const firstDay     = new Date(curr.y, curr.m, 1).getDay();

  const prevMonth = () => setCurr(p => ({ m: p.m === 0 ? 11 : p.m - 1, y: p.m === 0 ? p.y - 1 : p.y }));
  const nextMonth = () => setCurr(p => ({ m: p.m === 11 ? 0 : p.m + 1, y: p.m === 11 ? p.y + 1 : p.y }));

  return (
    <div className="page">
      {/* Header */}
      <div className="ph">
        <div>
          <div className="ph-title">📅 Calendar</div>
          <div className="ph-sub">Plan your days and track events</div>
        </div>
        <div className="ph-actions">
          <div className="row gap4">
            {["Day", "Week", "Month"].map(v => (
              <button key={v} className={`btn ${v === "Month" ? "btn-primary" : "btn-ghost"}`}>{v}</button>
            ))}
          </div>
          <button className="btn btn-teal">+ Event</button>
        </div>
      </div>

      <div className="g2">
        {/* Calendar grid */}
        <div className="card">
          <div className="row-between mb16">
            <span style={{ fontFamily: "var(--font-display)", fontSize: 17, fontWeight: 700 }}>
              {MONTH_NAMES[curr.m]} {curr.y}
            </span>
            <div className="row gap8">
              <button className="btn btn-ghost btn-sm" onClick={prevMonth}>‹</button>
              <button className="btn btn-ghost btn-sm" onClick={nextMonth}>›</button>
            </div>
          </div>

          <div className="cal-grid">
            {DAY_NAMES.map(d => <div key={d} className="cal-dn">{d}</div>)}

            {/* Leading empty cells */}
            {Array.from({ length: firstDay }, (_, i) => (
              <div key={`e${i}`} className="cal-day other">
                {new Date(curr.y, curr.m, -firstDay + i + 1).getDate()}
              </div>
            ))}

            {/* Day cells */}
            {Array.from({ length: daysInMonth }, (_, i) => {
              const d       = i + 1;
              const isToday = d === today.getDate() && curr.m === today.getMonth() && curr.y === today.getFullYear();
              const hasEv   = events.some(e => e.date === d && e.month === curr.m);
              return (
                <div key={d} className={`cal-day ${isToday ? "today" : ""} ${hasEv ? "has-ev" : ""}`}>
                  {d}
                </div>
              );
            })}
          </div>
        </div>

        {/* Right column */}
        <div className="col gap16">
          {/* Upcoming events */}
          <div className="card">
            <div className="card-title"><span className="card-title-icon">📌</span>Upcoming Events</div>
            {events.map((e, i) => (
              <div key={i} className="event-item">
                <span style={{ fontSize: 18 }}>{e.icon}</span>
                <div className="flex1">
                  <div style={{ fontSize: 13.5, fontWeight: 500 }}>{e.title}</div>
                  <div className="txs tdim mt8">
                    {e.date === today.getDate() ? "Today" : `In ${e.date - today.getDate()} days`} · {e.time}
                  </div>
                </div>
                <div className="event-dot" style={{ background: COLOR_VAR[e.color] ?? "var(--violet)" }} />
              </div>
            ))}
          </div>

          {/* Today's timeline */}
          <div className="card">
            <div className="card-title"><span className="card-title-icon">⏰</span>Today's Timeline</div>
            {STUDY_BLOCKS.slice(0, 4).map((b, i) => (
              <div key={i} className="tblock">
                <div className="tblock-time">{b.time}</div>
                <div className={`tblock-pill tb-${b.type}`} style={{ fontSize: 12 }}>{b.subject}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
