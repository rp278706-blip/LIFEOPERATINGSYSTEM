import { useState, useEffect, useRef } from "react";
import { sendCoachMessage } from "../../utils/api";
import { GOALS_CONFIG }     from "../../utils/constants";

const SUGGESTIONS = [
  "Analyze my diet today",
  "Create a study plan for GATE",
  "Improve my habits",
  "What should I prioritize?",
];

const INITIAL_MESSAGE = {
  role: "assistant",
  text: "Hey Arjun! 👋 I'm your personal AI coach. I have full context of your calories, habits, study schedule, and goals. What would you like to work on today?",
};

export function AICoach({ meals, habits, goals }) {
  const [messages, setMessages] = useState([INITIAL_MESSAGE]);
  const [input,    setInput]    = useState("");
  const [loading,  setLoading]  = useState(false);
  const bottomRef = useRef(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const buildContext = () => {
    const totalCals = meals.reduce((s, m) => s + m.calories, 0);
    return [
      `Calories: ${totalCals}/${GOALS_CONFIG.calories}`,
      `Habits: ${habits.map(h => `${h.name} streak ${h.streak}`).join(", ")}`,
      `Goals: ${goals.map(g => `${g.title} ${g.progress}%`).join(", ")}`,
    ].join(". ");
  };

  const send = async (overrideText) => {
    const userMsg = (overrideText ?? input).trim();
    if (!userMsg || loading) return;

    setInput("");
    const nextMessages = [...messages, { role: "user", text: userMsg }];
    setMessages(nextMessages);
    setLoading(true);

    const reply = await sendCoachMessage(userMsg, messages, buildContext());
    setMessages(prev => [...prev, { role: "assistant", text: reply }]);
    setLoading(false);
  };

  return (
    <div
      className="page"
      style={{ display: "flex", flexDirection: "column", height: "calc(100vh - 60px)", padding: "24px 32px" }}
    >
      {/* Header */}
      <div className="ph" style={{ marginBottom: 16 }}>
        <div>
          <div className="ph-title">✨ AI Coach</div>
          <div className="ph-sub">Your personal coach powered by Claude — knows your data</div>
        </div>
        <span className="tag tag-t">🟢 Active</span>
      </div>

      {/* Suggestion chips */}
      <div className="row gap8 mb16" style={{ flexWrap: "wrap" }}>
        {SUGGESTIONS.map(s => (
          <button key={s} className="chip" onClick={() => send(s)}>{s}</button>
        ))}
      </div>

      {/* Chat window */}
      <div className="card card-glass flex1" style={{ overflow: "hidden", display: "flex", flexDirection: "column", padding: 0 }}>
        <div style={{ flex: 1, overflowY: "auto", padding: 20 }}>
          {messages.map((m, i) => (
            <div
              key={i}
              style={{ display: "flex", justifyContent: m.role === "user" ? "flex-end" : "flex-start", marginBottom: 14 }}
            >
              {m.role === "assistant" && <div className="ai-avatar">✨</div>}
              <div
                className={`chat-bubble ${m.role}`}
                style={{ marginLeft: m.role === "assistant" ? 10 : 0 }}
              >
                {m.text}
              </div>
            </div>
          ))}

          {/* Loading dots */}
          {loading && (
            <div className="row gap8" style={{ marginBottom: 14 }}>
              <div className="ai-avatar">✨</div>
              <div className="chat-bubble assistant" style={{ marginLeft: 10 }}>
                <div className="ai-dots">
                  <div className="ai-dot" />
                  <div className="ai-dot" />
                  <div className="ai-dot" />
                </div>
              </div>
            </div>
          )}

          <div ref={bottomRef} />
        </div>

        {/* Input bar */}
        <div style={{
          padding: "14px 18px",
          borderTop: "1px solid var(--border)",
          display: "flex", gap: 10,
          background: "rgba(13,13,26,0.8)",
        }}>
          <input
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => e.key === "Enter" && send()}
            placeholder="Ask your AI coach anything..."
            style={{ flex: 1, background: "var(--surface)", border: "1px solid var(--border2)" }}
          />
          <button className="btn btn-primary" onClick={() => send()} disabled={loading}>
            {loading ? "..." : "Send ↑"}
          </button>
        </div>
      </div>
    </div>
  );
}
