import { useState } from "react";
import { GOALS_CONFIG, MEAL_ICONS } from "../../utils/constants";
import { ProgressRing } from "../../components/ui/ProgressRing";
import { Modal }        from "../../components/ui/Modal";
import { EmptyState }   from "../../components/ui/EmptyState";
import { BarChart }     from "../../components/charts";
import { AIInsight }    from "../../components/ai";
import { useToast }     from "../../context/ToastContext";

const MEAL_TYPES = ["all", "breakfast", "lunch", "dinner", "snacks"];

const WEEK_BASE = [
  { label: "M", value: 1950 }, { label: "T", value: 2100 },
  { label: "W", value: 1800 }, { label: "T", value: 2300 },
  { label: "F", value: 2050 }, { label: "S", value: 2400 },
];

const MACRO_CONFIG = [
  { key: "calories", label: "Calories", goal: GOALS_CONFIG.calories, color: "var(--amber)", barClass: "ca", unit: "kcal" },
  { key: "protein",  label: "Protein",  goal: GOALS_CONFIG.protein,  color: "var(--sky)",   barClass: "cs", unit: "g"    },
  { key: "carbs",    label: "Carbs",    goal: GOALS_CONFIG.carbs,    color: "#ffd166",      barClass: "",   unit: "g"    },
  { key: "fat",      label: "Fat",      goal: GOALS_CONFIG.fat,      color: "var(--rose)",  barClass: "cr", unit: "g"    },
];

const EMPTY_MEAL = { name: "", type: "breakfast", calories: "", protein: "", carbs: "", fat: "" };

export function CalorieTracker({ meals, setMeals }) {
  const [showModal, setShowModal] = useState(false);
  const [newMeal,   setNewMeal]   = useState(EMPTY_MEAL);
  const [filter,    setFilter]    = useState("all");
  const toast = useToast();

  // Totals
  const totals = meals.reduce(
    (s, m) => ({ calories: s.calories + m.calories, protein: s.protein + m.protein, carbs: s.carbs + m.carbs, fat: s.fat + m.fat }),
    { calories: 0, protein: 0, carbs: 0, fat: 0 }
  );

  const filtered  = filter === "all" ? meals : meals.filter(m => m.type === filter);
  const weekData  = [...WEEK_BASE, { label: "S", value: totals.calories }];

  const insightCtx = `Today: ${totals.calories}/${GOALS_CONFIG.calories} kcal, P: ${totals.protein}g, C: ${totals.carbs}g, F: ${totals.fat}g`;

  // Handlers
  const addMeal = () => {
    if (!newMeal.name || !newMeal.calories) return;
    setMeals(prev => [...prev, {
      id: Date.now(),
      ...newMeal,
      calories: +newMeal.calories,
      protein:  +newMeal.protein  || 0,
      carbs:    +newMeal.carbs    || 0,
      fat:      +newMeal.fat      || 0,
      icon:     MEAL_ICONS[newMeal.type] ?? "🍽️",
    }]);
    setNewMeal(EMPTY_MEAL);
    setShowModal(false);
    toast("Meal logged successfully!", "success");
  };

  const removeMeal = (id) => {
    setMeals(prev => prev.filter(m => m.id !== id));
    toast("Meal removed", "info");
  };

  return (
    <div className="page">
      {/* Header */}
      <div className="ph">
        <div>
          <div className="ph-title">🍎 Nutrition</div>
          <div className="ph-sub">Track macros and stay on target</div>
        </div>
        <div className="ph-actions">
          <button className="btn btn-primary" onClick={() => setShowModal(true)}>+ Add Meal</button>
        </div>
      </div>

      {/* Macro rings */}
      <div className="g4 mb20">
        {MACRO_CONFIG.map(m => (
          <div key={m.key} className="card hoverable" style={{ textAlign: "center" }}>
            <ProgressRing value={totals[m.key]} max={m.goal} color={m.color} size={88} sw={7} />
            <div style={{ marginTop: 10, fontSize: 13, fontWeight: 600 }}>{m.label}</div>
            <div className="txs tdim mt8">{totals[m.key]}{m.unit} / {m.goal}{m.unit}</div>
            {m.barClass && (
              <div className="pbar mt8">
                <div className={`pbar-fill ${m.barClass}`} style={{ width: `${Math.min(totals[m.key] / m.goal * 100, 100)}%` }} />
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Meal log */}
      <div className="card mb20">
        <div className="row-between mb16">
          <div className="card-title" style={{ marginBottom: 0 }}>
            <span className="card-title-icon">🍽️</span>Meal Log
          </div>
          <div className="row gap4">
            {MEAL_TYPES.map(t => (
              <button key={t} className={`chip ${filter === t ? "active" : ""}`} onClick={() => setFilter(t)}>
                {t.charAt(0).toUpperCase() + t.slice(1)}
              </button>
            ))}
          </div>
        </div>

        {filtered.length === 0
          ? <EmptyState icon="🥗" title="No meals yet" sub="Add your first meal to get started" />
          : filtered.map(m => (
            <div key={m.id} className="meal-row">
              <div className="meal-emoji">{m.icon}</div>
              <div className="flex1">
                <div className="meal-name">{m.name}</div>
                <div className="macros">
                  <span className="mpill mp-p">P: {m.protein}g</span>
                  <span className="mpill mp-c">C: {m.carbs}g</span>
                  <span className="mpill mp-f">F: {m.fat}g</span>
                </div>
              </div>
              <div style={{ textAlign: "right" }}>
                <div className="meal-kcal">{m.calories} kcal</div>
                <div className="txs tdim mt8" style={{ textTransform: "capitalize" }}>{m.type}</div>
              </div>
              <button
                className="btn btn-ghost btn-sm btn-icon"
                style={{ marginLeft: 8 }}
                onClick={() => removeMeal(m.id)}
              >✕</button>
            </div>
          ))
        }

        <div className="divider" />
        <div className="row-between">
          <span className="tsmall tmuted" style={{ fontWeight: 600 }}>Total Today</span>
          <span className="mono" style={{ color: "var(--amber)", fontWeight: 700, fontSize: 15 }}>
            {totals.calories} kcal
          </span>
        </div>
        <div className="pbar mt8">
          <div
            className="pbar-fill ca"
            style={{ width: `${Math.min(totals.calories / GOALS_CONFIG.calories * 100, 100)}%` }}
          />
        </div>
        <div className="row-between mt8">
          <span className="txs tdim">0 kcal</span>
          <span className="txs tdim">{GOALS_CONFIG.calories} kcal goal</span>
        </div>
      </div>

      {/* Charts + AI */}
      <div className="g2">
        <div className="card">
          <div className="card-title"><span className="card-title-icon">📊</span>Weekly Intake</div>
          <BarChart data={weekData} color="var(--amber)" />
        </div>
        <AIInsight
          prompt="Analyze calorie and macro intake and give specific diet improvement suggestions."
          context={insightCtx}
        />
      </div>

      {/* Add Meal Modal */}
      <Modal
        open={showModal}
        onClose={() => setShowModal(false)}
        title="Add Meal"
        footer={
          <>
            <button className="btn btn-ghost" onClick={() => setShowModal(false)}>Cancel</button>
            <button className="btn btn-primary" onClick={addMeal}>Add Meal</button>
          </>
        }
      >
        <div className="form-group">
          <label>Food Name</label>
          <input
            placeholder="e.g. Grilled Chicken"
            value={newMeal.name}
            onChange={e => setNewMeal(p => ({ ...p, name: e.target.value }))}
          />
        </div>
        <div className="form-group">
          <label>Meal Type</label>
          <select value={newMeal.type} onChange={e => setNewMeal(p => ({ ...p, type: e.target.value }))}>
            {["breakfast", "lunch", "dinner", "snacks"].map(t => (
              <option key={t} value={t}>{t.charAt(0).toUpperCase() + t.slice(1)}</option>
            ))}
          </select>
        </div>
        <div className="g2" style={{ gap: 10 }}>
          <div className="form-group">
            <label>Calories</label>
            <input type="number" placeholder="0" value={newMeal.calories} onChange={e => setNewMeal(p => ({ ...p, calories: e.target.value }))} />
          </div>
          <div className="form-group">
            <label>Protein (g)</label>
            <input type="number" placeholder="0" value={newMeal.protein} onChange={e => setNewMeal(p => ({ ...p, protein: e.target.value }))} />
          </div>
          <div className="form-group">
            <label>Carbs (g)</label>
            <input type="number" placeholder="0" value={newMeal.carbs} onChange={e => setNewMeal(p => ({ ...p, carbs: e.target.value }))} />
          </div>
          <div className="form-group">
            <label>Fat (g)</label>
            <input type="number" placeholder="0" value={newMeal.fat} onChange={e => setNewMeal(p => ({ ...p, fat: e.target.value }))} />
          </div>
        </div>
      </Modal>
    </div>
  );
}
