import { QUOTES, GOALS_CONFIG } from "../../utils/constants";
import { StatCard, ProgressRing }  from "../../components/ui";
import { BarChart }                from "../../components/charts";
import { AIInsight }               from "../../components/ai";

const WEEK_CALS = [
  { label: "M", value: 1950 }, { label: "T", value: 2100 },
  { label: "W", value: 1800 }, { label: "T", value: 2300 },
  { label: "F", value: 2050 }, { label: "S", value: 2400 },
];

export function Dashboard({ meals, habits, goals }) {
  const totalCals   = meals.reduce((s, m) => s + m.calories, 0);
  const doneHabits  = habits.filter(h => h.history[h.history.length - 1]).length;
  const avgGoalPct  = Math.round(goals.reduce((s, g) => s + g.progress, 0) / goals.length);
  const studyH      = 6.5;
  const quote       = QUOTES[Math.floor(Math.random() * QUOTES.length)];

  const weekCals = [...WEEK_CALS, { label: "S", value: totalCals }];

  const insightCtx = `Calories: ${totalCals}/${GOALS_CONFIG.calories}, Study: ${studyH}/8h, Habits: ${doneHabits}/${habits.length}, Goals avg: ${avgGoalPct}%`;

  return (
    <div className="page">
      {/* Header */}
      <div className="ph">
        <div>
          <div className="ph-title">Good morning, Arjun 👋</div>
          <div className="ph-sub">
            {new Date().toLocaleDateString("en-IN", { weekday: "long", year: "numeric", month: "long", day: "numeric" })}
          </div>
        </div>
        <div className="ph-actions">
          <button className="btn btn-ghost">📤 Export</button>
          <button className="btn btn-primary">⚡ Daily Plan</button>
        </div>
      </div>

      {/* Quote */}
      <div className="quote-strip mb20">
        <div className="quote-q">"</div>
        <div>
          <div className="quote-text">{quote.text}</div>
          <div className="quote-author">— {quote.author}</div>
        </div>
      </div>

      {/* KPI Stat Cards */}
      <div className="g4 mb20">
        <StatCard
          variant="sa" emoji="🔥" label="Calories Today"
          value={totalCals} sub={`Goal: ${GOALS_CONFIG.calories} kcal`}
          progress={(totalCals / GOALS_CONFIG.calories) * 100} barClass="ca"
        />
        <StatCard
          variant="sv" emoji="📚" label="Study Hours"
          value={`${studyH}h`} sub={`Target: ${GOALS_CONFIG.studyHrs}h/day`}
          progress={(studyH / GOALS_CONFIG.studyHrs) * 100} barClass="cv"
        />
        <StatCard
          variant="st" emoji="✅" label="Habits Done"
          value={`${doneHabits}/${habits.length}`} sub="Today's streak"
          progress={(doneHabits / habits.length) * 100} barClass="ct"
        />
        <StatCard
          variant="sr" emoji="🎯" label="Goals Progress"
          value={`${avgGoalPct}%`} sub={`${goals.length} active goals`}
          progress={avgGoalPct} barClass="cr"
        />
      </div>

      {/* Charts + Habits */}
      <div className="g2 mb20">
        <div className="card">
          <div className="card-title"><span className="card-title-icon">📊</span>Weekly Calories</div>
          <BarChart data={weekCals} color="var(--amber)" />
          <div className="row gap8 mt12">
            <span className="tag tag-a">Avg: 2,085 kcal</span>
            <span className="tag tag-t">Goal: 2,200</span>
          </div>
        </div>

        <div className="card">
          <div className="card-title"><span className="card-title-icon">✅</span>Today's Habits</div>
          {habits.slice(0, 4).map(h => (
            <div
              key={h.id}
              className="row gap12"
              style={{ padding: "8px 0", borderBottom: "1px solid var(--border)" }}
            >
              <span style={{ fontSize: 17 }}>{h.icon}</span>
              <span className="tsmall flex1">{h.name}</span>
              <span className="tag tag-a" style={{ fontSize: 10 }}>🔥 {h.streak}d</span>
              <div
                className={`habit-check ${h.history[h.history.length - 1] ? "done" : ""}`}
                style={{ width: 22, height: 22, fontSize: 10 }}
              >
                {h.history[h.history.length - 1] ? "✓" : ""}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* AI Insight */}
      <div className="mb20">
        <AIInsight
          prompt="Give a personalized motivational insight and top priority for today based on dashboard data."
          context={insightCtx}
        />
      </div>

      {/* Goal Progress Rings */}
      <div className="card">
        <div className="card-title"><span className="card-title-icon">🎯</span>Goal Progress</div>
        <div className="g3">
          {goals.map(g => {
            const col = g.color === "violet" ? "var(--violet)" : g.color === "teal" ? "var(--teal)" : "var(--amber)";
            return (
              <div key={g.id} className="card hoverable" style={{ padding: 16, background: "var(--bg3)" }}>
                <div className="row gap8 mb12">
                  <span style={{ fontSize: 20 }}>{g.icon}</span>
                  <div>
                    <div style={{ fontSize: 13, fontWeight: 600 }}>{g.title}</div>
                    <div className="txs tdim">Due {g.deadline}</div>
                  </div>
                </div>
                <div className="row gap12">
                  <ProgressRing value={g.progress} max={100} color={col} size={72} sw={6} />
                  <div>
                    <div style={{ fontFamily: "var(--font-display)", fontSize: 22, fontWeight: 800, color: col }}>
                      {g.progress}%
                    </div>
                    <div className="txs tdim">
                      {g.milestones.filter(m => m.done).length}/{g.milestones.length} done
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
