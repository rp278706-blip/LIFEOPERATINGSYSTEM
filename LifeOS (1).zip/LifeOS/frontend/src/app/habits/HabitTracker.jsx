import { useState } from "react";
import { Modal }    from "../../components/ui/Modal";
import { AIInsight } from "../../components/ai";
import { useHeatmap } from "../../hooks/useHeatmap";
import { useToast }   from "../../context/ToastContext";

export function HabitTracker({ habits, setHabits }) {
  const [showModal, setShowModal] = useState(false);
  const [newHabit,  setNewHabit]  = useState({ name: "", icon: "⭐" });
  const heatmap = useHeatmap();
  const toast   = useToast();

  const toggle = (id) => {
    setHabits(prev => prev.map(h => {
      if (h.id !== id) return h;
      const wasChecked = h.history[h.history.length - 1];
      return {
        ...h,
        history: h.history.map((v, i) => i === h.history.length - 1 ? (v ? 0 : 1) : v),
        streak:  wasChecked ? Math.max(0, h.streak - 1) : h.streak + 1,
      };
    }));
  };

  const addHabit = () => {
    if (!newHabit.name) return;
    setHabits(prev => [...prev, {
      id:      Date.now(),
      ...newHabit,
      streak:  0,
      history: [0, 0, 0, 0, 0, 0, 0],
      pct:     0,
    }]);
    setNewHabit({ name: "", icon: "⭐" });
    setShowModal(false);
    toast("New habit created!", "success");
  };

  const insightCtx = habits.map(h => `${h.name} streak:${h.streak} success:${h.pct}%`).join(", ");

  return (
    <div className="page">
      {/* Header */}
      <div className="ph">
        <div>
          <div className="ph-title">✅ Habit Tracker</div>
          <div className="ph-sub">Build consistency, one day at a time</div>
        </div>
        <div className="ph-actions">
          <button className="btn btn-primary" onClick={() => setShowModal(true)}>+ New Habit</button>
        </div>
      </div>

      {/* Heatmap */}
      <div className="card mb20">
        <div className="card-title"><span className="card-title-icon">🗓</span>Activity Heatmap — Last Year</div>
        <div className="scroll-x">
          <div className="heatmap" style={{ minWidth: 600 }}>
            {heatmap.map((v, i) => (
              <div key={i} className={`hmap-cell ${v ? `l${v}` : ""}`} />
            ))}
          </div>
        </div>
        <div className="row gap8 mt8">
          <span className="txs tdim">Less</span>
          {[0, 1, 2, 3, 4].map(l => (
            <div key={l} className={`hmap-cell ${l ? `l${l}` : ""}`} style={{ width: 12, height: 12, flexShrink: 0 }} />
          ))}
          <span className="txs tdim">More</span>
        </div>
      </div>

      <div className="g2 mb20">
        {/* Habit list */}
        <div className="card">
          <div className="card-title"><span className="card-title-icon">📋</span>Today's Habits</div>
          {habits.map(h => (
            <div key={h.id} className="habit-row">
              <span style={{ fontSize: 19, flexShrink: 0 }}>{h.icon}</span>
              <div className="flex1">
                <div className="habit-name">{h.name}</div>
                <div className="row gap4 mt8">
                  <div className="habit-mini">
                    {h.history.map((d, i) => (
                      <div
                        key={i}
                        className={`hm-dot ${d ? "on" : ""} ${i === h.history.length - 1 ? "today" : ""}`}
                      />
                    ))}
                  </div>
                  <span className="txs tdim">{h.pct}%</span>
                </div>
              </div>
              <span className="habit-streak-badge">🔥 {h.streak}d</span>
              <div
                className={`habit-check ${h.history[h.history.length - 1] ? "done" : ""}`}
                onClick={() => toggle(h.id)}
              >
                {h.history[h.history.length - 1] ? "✓" : ""}
              </div>
            </div>
          ))}
        </div>

        {/* Right column: streak leaders + AI */}
        <div className="col gap16">
          <div className="card">
            <div className="card-title"><span className="card-title-icon">🏆</span>Streak Leaders</div>
            {[...habits].sort((a, b) => b.streak - a.streak).map((h, i) => (
              <div
                key={h.id}
                className="row gap12"
                style={{ padding: "9px 0", borderBottom: "1px solid var(--border)" }}
              >
                <span className="mono txs tdim" style={{ width: 16 }}>#{i + 1}</span>
                <span style={{ fontSize: 17 }}>{h.icon}</span>
                <span className="tsmall flex1">{h.name}</span>
                <span className="habit-streak-badge">🔥 {h.streak}</span>
              </div>
            ))}
          </div>

          <AIInsight
            prompt="Analyze habit tracking data and suggest specific improvements."
            context={insightCtx}
          />
        </div>
      </div>

      {/* Add Habit Modal */}
      <Modal
        open={showModal}
        onClose={() => setShowModal(false)}
        title="Create New Habit"
        footer={
          <>
            <button className="btn btn-ghost" onClick={() => setShowModal(false)}>Cancel</button>
            <button className="btn btn-primary" onClick={addHabit}>Create Habit</button>
          </>
        }
      >
        <div className="form-group">
          <label>Habit Name</label>
          <input
            placeholder="e.g. Morning Run"
            value={newHabit.name}
            onChange={e => setNewHabit(p => ({ ...p, name: e.target.value }))}
          />
        </div>
        <div className="form-group">
          <label>Icon (emoji)</label>
          <input
            placeholder="🏃"
            value={newHabit.icon}
            onChange={e => setNewHabit(p => ({ ...p, icon: e.target.value }))}
          />
        </div>
      </Modal>
    </div>
  );
}
