import { useState } from "react";

// Context
import { ToastProvider } from "./context/ToastContext";

// Layout
import { Sidebar } from "./components/layout/Sidebar";
import { Topbar  } from "./components/layout/Topbar";

// Pages
import { Dashboard      } from "./app/dashboard/Dashboard";
import { CalorieTracker } from "./app/calories/CalorieTracker";
import { StudyScheduler } from "./app/study/StudyScheduler";
import { HabitTracker   } from "./app/habits/HabitTracker";
import { CalendarPage   } from "./app/calendar/CalendarPage";
import { Goals          } from "./app/goals/Goals";
import { AICoach        } from "./app/ai/AICoach";

// Data
import { INITIAL_MEALS, INITIAL_HABITS, INITIAL_GOALS } from "./utils/constants";


// ─── Page router ────────────────────────────────────────────
function renderPage(page, props) {
  switch (page) {
    case "dashboard": return <Dashboard      meals={props.meals} habits={props.habits} goals={props.goals} />;
    case "calories":  return <CalorieTracker meals={props.meals} setMeals={props.setMeals} />;
    case "study":     return <StudyScheduler />;
    case "habits":    return <HabitTracker   habits={props.habits} setHabits={props.setHabits} />;
    case "calendar":  return <CalendarPage />;
    case "goals":     return <Goals          goals={props.goals}  setGoals={props.setGoals} />;
    case "ai":        return <AICoach        meals={props.meals}  habits={props.habits} goals={props.goals} />;
    default:          return <Dashboard      meals={props.meals} habits={props.habits} goals={props.goals} />;
  }
}

// ─── Root ───────────────────────────────────────────────────
export default function App() {
  const [page,      setPage]      = useState("dashboard");
  const [collapsed, setCollapsed] = useState(false);

  // Global state
  const [meals,  setMeals]  = useState(INITIAL_MEALS);
  const [habits, setHabits] = useState(INITIAL_HABITS);
  const [goals,  setGoals]  = useState(INITIAL_GOALS);

  const pageProps = { meals, setMeals, habits, setHabits, goals, setGoals };

  return (
    <ToastProvider>
      {/* Inject global CSS */}

      {/* Ambient background */}
      <div className="ambient">
        <div className="blob blob-1" />
        <div className="blob blob-2" />
        <div className="blob blob-3" />
      </div>
      <div className="noise" />

      {/* Shell */}
      <div className="app-shell">
        <Sidebar
          page={page}
          setPage={setPage}
          collapsed={collapsed}
          setCollapsed={setCollapsed}
        />

        <div className="main-wrap">
          <Topbar page={page} />
          <div className="page-area">
            {renderPage(page, pageProps)}
          </div>
        </div>
      </div>
    </ToastProvider>
  );
}
